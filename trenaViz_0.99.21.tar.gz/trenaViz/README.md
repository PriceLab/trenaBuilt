# BrowserVizTemplate
All the files and directories - skeletal versions - needed to build a BrowserViz app (R &lt;-> browser)
