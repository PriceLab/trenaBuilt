network = {"nodes": [{"data":  {"id":"n1"}},{"data":  {"id":"n2"}}],
	   "edges": [{"data":  {"id":"n1->n1","source":"n1","target":"n1"}},
		     {"data":  {"id":"n1->n2","source":"n1","target":"n2"}}]}

